                                        // Questions and Answers

var num;